package com.example.rentaflat.flat;

public class FlatState extends FlatViewModel {

    // put the model state here
}