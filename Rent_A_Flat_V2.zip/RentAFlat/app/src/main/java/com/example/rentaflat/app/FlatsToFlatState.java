package com.example.rentaflat.app;


import com.example.rentaflat.data.FlatItem;

public class FlatsToFlatState {

    public FlatItem flat;
    public int userID;

}
