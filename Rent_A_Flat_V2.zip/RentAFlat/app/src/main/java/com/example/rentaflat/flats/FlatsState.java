package com.example.rentaflat.flats;

public class FlatsState extends FlatsViewModel {

    // put the model state here
}