package com.example.rentaflat.flats;

import com.example.rentaflat.data.FlatItem;

import java.util.List;

public class FlatsViewModel {

    // put the view state here
    public boolean favoritesSelected;
    public int userId;
    public List<FlatItem> flats;
    public List<FlatItem> favoriteFlats;
}