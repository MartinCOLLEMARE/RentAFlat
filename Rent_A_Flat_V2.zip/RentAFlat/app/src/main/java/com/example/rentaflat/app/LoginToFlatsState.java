package com.example.rentaflat.app;

public class LoginToFlatsState {

    public int id_user;
}
