package com.example.rentaflat.flat;

import com.example.rentaflat.data.FlatItem;

public class FlatViewModel {

    // put the view state here
    public FlatItem flat;
    public boolean addedToFavorites;
    public boolean booked;
    public int userId;

}