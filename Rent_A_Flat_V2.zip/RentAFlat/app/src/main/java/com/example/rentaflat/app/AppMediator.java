package com.example.rentaflat.app;

import com.example.rentaflat.data.FlatItem;
import com.example.rentaflat.flat.FlatState;
import com.example.rentaflat.flats.FlatsState;

import java.util.List;

@SuppressWarnings("unused")
public class AppMediator {

    private static AppMediator INSTANCE;

    private FlatsState flatsState;
    private FlatState flatState;

    private FlatsToFlatState flatsToFlatState;


    private AppMediator() {
        flatsState = new FlatsState();
        flatsToFlatState = new FlatsToFlatState();
        flatState = new FlatState();

    }


    public static AppMediator getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new AppMediator();
        }

        return INSTANCE;
    }

    // to reset the state when testing
    public static void resetInstance() { INSTANCE = null; }

    public FlatsState getFlatsState() { return flatsState;}
    public FlatState getFlatState() { return flatState;}

    public FlatsToFlatState getFlatsToFlatState() {
        FlatsToFlatState state = flatsToFlatState;
        flatsToFlatState = null;
        return state;
    }

    public void setFlatsToFlatState(FlatsToFlatState state) {
        this.flatsToFlatState = state;
    }




}

